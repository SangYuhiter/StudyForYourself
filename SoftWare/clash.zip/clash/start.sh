# start with this
./clash-linux-amd64-v1.10.0 -f glados.yaml -d .
