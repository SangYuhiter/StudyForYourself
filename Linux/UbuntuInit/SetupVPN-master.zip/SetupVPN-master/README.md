# Chrome-SetupVPN-3.9.8

```SetupVPN
setupvpn for chrome
```

# 官网

```官网
https://setupvpn.com/download/（需翻墙访问）
```

# 安装

```1
1.git clone or download zip(完成后需解压);
```

```2
2.打开谷歌浏览器 右上角的三个点 --> 更多工具 --> 扩展程序(或者直接地址栏输入 chrome://extensions/ )
```

![image](https://github.com/qin-ziqi/Chrome-SetupVPN-3.7.0/blob/master/imgs/step1.png)

```3
3.打开开发者模式 --> 加载已解压的扩展程序
```

![image](https://github.com/qin-ziqi/Chrome-SetupVPN-3.7.0/blob/master/imgs/step2.png)

```4
4.选择该文件夹
```

![image](https://github.com/qin-ziqi/Chrome-SetupVPN-3.7.0/blob/master/imgs/step3.png)

```5
5.扩展程序中出现如图所示的图标，表示插件已安装成功
```

![image](https://github.com/qin-ziqi/Chrome-SetupVPN-3.7.0/blob/master/imgs/step4.png)

```6
6.点击该扩展程序，然后注册账号 --> 登录账号 --> 选择要连接的 vpn 就可以了
```

![image](https://github.com/qin-ziqi/Chrome-SetupVPN-3.7.0/blob/master/imgs/step5.png)
